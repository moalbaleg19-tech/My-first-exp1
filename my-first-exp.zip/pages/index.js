export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Selamat datang di My First Exp!</h1>
      <p>Berikut contoh video dari link eksternal:</p>

      <video width="640" height="360" controls>
        <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
        Browser kamu tidak mendukung tag video.
      </video>

      <p>Video ini diambil dari URL publik → tidak perlu taruh di project kamu.</p>
    </div>
  );
}